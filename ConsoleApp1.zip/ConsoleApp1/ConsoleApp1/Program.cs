﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //for (int i = 0; i < 10; ++i)
            //{
            //    System.Threading.Thread.Sleep(500);
            //    Console.Write("\r{0}%   ", i);
            //}


            //string line = "";

            //for (int i = 0; i < 100; i++)
            //{
            //    System.Threading.Thread.Sleep(500);
            //    string backup = new string('\b', line.Length);
            //    Console.Write(backup);
            //    line = string.Format("{0}%", i);
            //    Console.Write(line);
            //}

            //Console.Read();

            //Console.SetWindowSize(90, 15);

            Random rng = new Random();

            int row = 0;

            Console.SetCursorPosition(1, row);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("SMSReceiver");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write(" by ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("fb@kingpauloaquino");


            row++;


            row++;
            // status
            Console.SetCursorPosition(1, row);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Modem Status");
            Console.SetCursorPosition(30, row);
            Console.Write("Online");


            row++;
            // license
            Console.SetCursorPosition(1, row);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write("License");
            Console.SetCursorPosition(30, row);
            Console.Write("PRO-Standard");

            row++;
            // version
            Console.SetCursorPosition(1, row);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write("Version");
            Console.SetCursorPosition(30, row);
            Console.Write("2.1.0");

            row++;
            // signal
            Console.SetCursorPosition(1, row);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write("Signal");
            Console.SetCursorPosition(30, row);
            Console.Write(rng.Next(99) + "%");
            
            row++;
            // network
            Console.SetCursorPosition(1, row);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write("Network");
            Console.SetCursorPosition(30, row);
            Console.Write("SMART");

            row++;
            // number
            Console.SetCursorPosition(1, row);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write("Number");
            Console.SetCursorPosition(30, row);
            Console.Write("09171236547");







            //for (int row = 1; row < 10; row++)
            //{
            //    Console.SetCursorPosition(0, row);
            //    Console.Write("#                              #");
            //}
            //Console.SetCursorPosition(0, 10);
            //Console.Write("################################");

            //int data = 1;
            //System.Diagnostics.Stopwatch clock = new System.Diagnostics.Stopwatch();
            //clock.Start();
            //while (true)
            //{
            //    data++;
            //    Console.SetCursorPosition(1, 2);
            //    Console.Write("Current Value: " + data.ToString());
            //    Console.SetCursorPosition(1, 3);
            //    Console.Write("Running Time: " + clock.Elapsed.TotalSeconds.ToString());
            //    Thread.Sleep(1000);
            //}

            Console.ReadKey();
        }
    }
}
